#!/usr/bin/env python3
"""
app.py - Main Application File
Personal Finance Tracker - My Paldea
Team Project - IST 303 Fall 2025

This is a simplified version focusing on Qiao Huang's Tasks 8-9 (Budget Features)
for demonstration purposes.
"""

from flask import Flask, render_template_string, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime
import os
from werkzeug.security import generate_password_hash, check_password_hash

# Create Flask application
app = Flask(__name__)
app.secret_key = 'personal-finance-tracker-2025-secret-key'

# Database helper functions
def get_db_connection():
    """Create database connection"""
    conn = sqlite3.connect('finance.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database with all required tables"""
    conn = get_db_connection()
    c = conn.cursor()
    
    # Users table (Task 1 - Gerves)
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Transactions table (Tasks 3-7 - Samantha)
    c.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            date DATE NOT NULL,
            type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Budgets table (Task 8 - Qiao)
    c.execute('''
        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            month TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            UNIQUE(user_id, category, month)
        )
    ''')
    
    # Create demo user for testing
    demo_password = generate_password_hash('demo123')
    c.execute('''
        INSERT OR IGNORE INTO users (id, username, password_hash, email)
        VALUES (1, 'demo', ?, 'demo@example.com')
    ''', (demo_password,))
    
    conn.commit()
    conn.close()
    print("✅ Database initialized successfully!")

# Routes
@app.route('/')
def home():
    """Home page"""
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Personal Finance Tracker - My Paldea</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Segoe UI', Arial, sans-serif; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .container { 
                background: white; 
                padding: 40px; 
                border-radius: 20px; 
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                max-width: 600px;
                width: 90%;
            }
            h1 { 
                color: #333; 
                text-align: center;
                margin-bottom: 10px;
                font-size: 2.5em;
            }
            h2 {
                text-align: center;
                color: #666;
                font-size: 1.2em;
                margin-bottom: 30px;
            }
            .team-info {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 10px;
                margin-bottom: 30px;
            }
            .team-info h3 {
                color: #667eea;
                margin-bottom: 10px;
            }
            .menu { 
                display: flex; 
                flex-direction: column; 
                gap: 15px; 
            }
            .menu a { 
                display: block; 
                padding: 18px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; 
                text-decoration: none; 
                text-align: center; 
                border-radius: 10px;
                font-size: 1.1em;
                font-weight: 500;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .menu a:hover { 
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            }
            .menu a.demo {
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            }
            .login-info {
                background: #e8f4fd;
                padding: 15px;
                border-radius: 10px;
                margin-top: 20px;
                text-align: center;
            }
            .footer {
                text-align: center;
                margin-top: 30px;
                color: #999;
                font-size: 0.9em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>💰 Personal Finance Tracker</h1>
            <h2>My Paldea - Budget Management System</h2>
            
            <div class="team-info">
                <h3>Team Project - IST 303 Fall 2025</h3>
                <p><strong>Featured: Tasks 8-9 by Qiao Huang</strong></p>
                <ul style="margin-left: 20px; margin-top: 10px;">
                    <li>Task 8: Monthly Budget Setting</li>
                    <li>Task 9: Progress Bar Visualization</li>
                </ul>
            </div>
            
            <div class="menu">
                {% if session.get('user_id') %}
                    <a href="/dashboard">📊 Dashboard</a>
                    <a href="/budget">💵 Set Monthly Budgets (Task 8)</a>
                    <a href="/budget_progress">📈 View Progress Bars (Task 9)</a>
                    <a href="/transactions">💳 Manage Transactions</a>
                    <a href="/logout">🚪 Logout</a>
                {% else %}
                    <a href="/login">🔐 Login</a>
                    <a href="/register">📝 Register</a>
                    <a href="/demo" class="demo">🎮 Quick Demo (No Login)</a>
                {% endif %}
                <a href="/add_sample_data" style="background: #28a745;">🔧 Load Sample Data</a>
            </div>
            
            {% if not session.get('user_id') %}
            <div class="login-info">
                <strong>Demo Account:</strong><br>
                Username: demo | Password: demo123
            </div>
            {% endif %}
            
            <div class="footer">
                <p>Developed by: Gerves B., Samantha A., <strong>Qiao H.</strong>, Manish S., Rachan S.</p>
            </div>
        </div>
    </body>
    </html>
    ''', session=session)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect('/dashboard')
        else:
            error = 'Invalid username or password'
            
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login - Personal Finance Tracker</title>
        <style>
            body { 
                font-family: Arial; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .login-form { 
                background: white; 
                padding: 40px; 
                border-radius: 10px; 
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                width: 400px;
            }
            h2 { text-align: center; color: #333; margin-bottom: 30px; }
            input { 
                width: 100%; 
                padding: 12px; 
                margin: 10px 0; 
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
            }
            button { 
                width: 100%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; 
                padding: 12px; 
                border: none; 
                border-radius: 5px; 
                cursor: pointer;
                font-size: 16px;
                margin-top: 10px;
            }
            button:hover { opacity: 0.9; }
            .demo-info {
                background: #f0f0f0;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="login-form">
            <h2>🔐 Login</h2>
            <form method="post">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <div class="demo-info">
                <strong>Demo Account:</strong><br>
                Username: demo<br>
                Password: demo123
            </div>
            <p style="text-align: center; margin-top: 20px;">
                <a href="/" style="color: #667eea;">← Back to Home</a>
            </p>
        </div>
    </body>
    </html>
    ''')

@app.route('/dashboard')
def dashboard():
    """Dashboard page"""
    if 'user_id' not in session:
        return redirect('/login')
    
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Dashboard</title>
        <style>
            body { font-family: Arial; margin: 20px; background: #f5f5f5; }
            .container { max-width: 1200px; margin: 0 auto; }
            h1 { color: #333; }
            .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px; }
            .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .card h3 { color: #667eea; margin-bottom: 15px; }
            .btn { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 10px; }
            .btn:hover { background: #5a67d8; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome, {{ session.username }}!</h1>
            
            <div class="cards">
                <div class="card">
                    <h3>💵 Budget Management</h3>
                    <p>Set and monitor your monthly spending limits</p>
                    <a href="/budget" class="btn">Set Budgets</a>
                    <a href="/budget_progress" class="btn">View Progress</a>
                </div>
                
                <div class="card">
                    <h3>💳 Transactions</h3>
                    <p>Track your income and expenses</p>
                    <a href="/transactions" class="btn">Manage Transactions</a>
                </div>
                
                <div class="card">
                    <h3>📊 Quick Stats</h3>
                    <p>This month's overview coming soon...</p>
                </div>
            </div>
            
            <p style="margin-top: 30px;">
                <a href="/" style="color: #667eea;">← Back to Home</a> |
                <a href="/logout" style="color: #667eea;">Logout</a>
            </p>
        </div>
    </body>
    </html>
    ''', session=session)

@app.route('/budget')
def budget():
    """Task 8: Budget setting page"""
    if 'user_id' not in session:
        return redirect('/login')
    
    conn = get_db_connection()
    current_month = datetime.now().strftime('%Y-%m')
    budgets = conn.execute('''
        SELECT * FROM budgets 
        WHERE user_id = ? AND month = ?
        ORDER BY category
    ''', (session['user_id'], current_month)).fetchall()
    conn.close()
    
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Set Budget - Task 8</title>
        <style>
            body { font-family: Arial; margin: 20px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            h1 { color: #333; text-align: center; }
            .task-badge { background: #667eea; color: white; padding: 5px 10px; border-radius: 5px; font-size: 0.9em; }
            form { background: #f9f9f9; padding: 20px; border-radius: 5px; margin: 20px 0; }
            select, input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { background: #667eea; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
            button:hover { background: #5a67d8; }
            .budget-list { margin-top: 30px; }
            .budget-item { display: flex; justify-content: space-between; padding: 15px; background: #f0f0f0; margin: 10px 0; border-radius: 5px; border-left: 4px solid #667eea; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Set Monthly Budget <span class="task-badge">Task 8</span></h1>
            <p style="text-align: center; color: #666;">Developer: Qiao Huang</p>
            
            <form action="/add_budget" method="post">
                <label>Category:</label>
                <select name="category" required>
                    <option value="">Select Category...</option>
                    <option value="Food">🍔 Food</option>
                    <option value="Transportation">🚗 Transportation</option>
                    <option value="Entertainment">🎬 Entertainment</option>
                    <option value="Shopping">🛍️ Shopping</option>
                    <option value="Utilities">💡 Utilities</option>
                    <option value="Healthcare">🏥 Healthcare</option>
                    <option value="Other">📌 Other</option>
                </select>
                
                <label>Budget Amount ($):</label>
                <input type="number" name="amount" step="0.01" min="0" required placeholder="500.00">
                
                <button type="submit">Set Budget</button>
            </form>
            
            <div class="budget-list">
                <h2>Current Month Budgets ({{ current_month }}):</h2>
                {% if budgets %}
                    {% for budget in budgets %}
                    <div class="budget-item">
                        <span>{{ budget['category'] }}</span>
                        <span style="font-size: 1.2em; color: #667eea;">${{ "%.2f"|format(budget['amount']) }}</span>
                    </div>
                    {% endfor %}
                {% else %}
                    <p style="text-align: center; color: #999;">No budgets set yet. Add one above!</p>
                {% endif %}
            </div>
            
            <p style="margin-top: 30px; text-align: center;">
                <a href="/dashboard" style="color: #667eea;">← Back to Dashboard</a> |
                <a href="/budget_progress" style="color: #667eea;">View Progress →</a>
            </p>
        </div>
    </body>
    </html>
    ''', budgets=budgets, current_month=datetime.now().strftime('%B %Y'))

@app.route('/add_budget', methods=['POST'])
def add_budget():
    """Process budget form submission"""
    if 'user_id' not in session:
        return redirect('/login')
    
    category = request.form['category']
    amount = float(request.form['amount'])
    current_month = datetime.now().strftime('%Y-%m')
    
    conn = get_db_connection()
    c = conn.cursor()
    
    c.execute('''
        INSERT OR REPLACE INTO budgets (user_id, category, amount, month)
        VALUES (?, ?, ?, ?)
    ''', (session['user_id'], category, amount, current_month))
    
    conn.commit()
    conn.close()
    
    return redirect('/budget')

@app.route('/budget_progress')
def budget_progress():
    """Task 9: Budget progress visualization"""
    if 'user_id' not in session:
        return redirect('/login')
    
    conn = get_db_connection()
    current_month = datetime.now().strftime('%Y-%m')
    
    # Get budgets with spending
    budgets = conn.execute('''
        SELECT b.category, b.amount,
               COALESCE(SUM(t.amount), 0) as spent
        FROM budgets b
        LEFT JOIN transactions t ON 
            t.user_id = b.user_id AND 
            t.category = b.category AND 
            strftime('%Y-%m', t.date) = b.month AND
            t.type = 'expense'
        WHERE b.user_id = ? AND b.month = ?
        GROUP BY b.category, b.amount
        ORDER BY b.category
    ''', (session['user_id'], current_month)).fetchall()
    
    conn.close()
    
    progress_data = []
    for budget in budgets:
        percentage = (budget['spent'] / budget['amount'] * 100) if budget['amount'] > 0 else 0
        remaining = budget['amount'] - budget['spent']
        
        if percentage <= 50:
            color = '#4CAF50'  # Green
            status = 'On Track'
        elif percentage <= 80:
            color = '#FFC107'  # Yellow  
            status = 'Caution'
        elif percentage <= 100:
            color = '#FF9800'  # Orange
            status = 'Warning'
        else:
            color = '#f44336'  # Red
            status = 'Over Budget!'
        
        progress_data.append({
            'category': budget['category'],
            'budget': budget['amount'],
            'spent': budget['spent'],
            'remaining': remaining,
            'percentage': min(percentage, 100),
            'actual_percentage': percentage,
            'color': color,
            'status': status
        })
    
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Budget Progress - Task 9</title>
        <style>
            body { font-family: Arial; margin: 20px; background: #f5f5f5; }
            .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            h1 { color: #333; text-align: center; }
            .task-badge { background: #667eea; color: white; padding: 5px 10px; border-radius: 5px; font-size: 0.9em; }
            .legend { display: flex; justify-content: center; gap: 20px; margin: 20px 0; padding: 15px; background: #f0f0f0; border-radius: 5px; }
            .legend-item { display: flex; align-items: center; gap: 5px; }
            .legend-color { width: 20px; height: 20px; border-radius: 3px; }
            .progress-item { margin: 30px 0; padding: 20px; background: #f9f9f9; border-radius: 10px; }
            .progress-header { display: flex; justify-content: space-between; margin-bottom: 10px; }
            .progress-bar-container { width: 100%; height: 40px; background: #e0e0e0; border-radius: 20px; overflow: hidden; }
            .progress-bar { height: 100%; display: flex; align-items: center; padding: 0 15px; color: white; font-weight: bold; transition: width 0.5s; }
            .stats { display: flex; justify-content: space-between; margin-top: 10px; font-size: 0.9em; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📈 Budget Progress Tracker <span class="task-badge">Task 9</span></h1>
            <p style="text-align: center; color: #666;">Developer: Qiao Huang | Visual progress bars with color coding</p>
            
            <div class="legend">
                <div class="legend-item">
                    <div class="legend-color" style="background: #4CAF50;"></div>
                    <span>0-50% (Safe)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #FFC107;"></div>
                    <span>51-80% (Caution)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #FF9800;"></div>
                    <span>81-100% (Warning)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #f44336;"></div>
                    <span>Over Budget!</span>
                </div>
            </div>
            
            {% if progress_data %}
                {% for item in progress_data %}
                <div class="progress-item">
                    <div class="progress-header">
                        <h3>{{ item.category }}</h3>
                        <span style="color: {{ item.color }}; font-weight: bold;">{{ item.status }}</span>
                    </div>
                    
                    <div class="progress-bar-container">
                        <div class="progress-bar" style="width: {{ item.percentage }}%; background: {{ item.color }};">
                            {{ "%.0f"|format(item.actual_percentage) }}%
                        </div>
                    </div>
                    
                    <div class="stats">
                        <span>Budget: ${{ "%.2f"|format(item.budget) }}</span>
                        <span>Spent: ${{ "%.2f"|format(item.spent) }}</span>
                        <span {% if item.remaining < 0 %}style="color: #f44336;"{% else %}style="color: #4CAF50;"{% endif %}>
                            Remaining: ${{ "%.2f"|format(item.remaining) }}
                        </span>
                    </div>
                </div>
                {% endfor %}
            {% else %}
                <p style="text-align: center; color: #999; margin: 50px 0;">
                    No budgets set for this month. <a href="/budget" style="color: #667eea;">Set your budgets</a> to start tracking!
                </p>
            {% endif %}
            
            <p style="margin-top: 30px; text-align: center;">
                <a href="/budget" style="color: #667eea;">← Set Budgets</a> |
                <a href="/dashboard" style="color: #667eea;">Dashboard</a>
            </p>
        </div>
    </body>
    </html>
    ''', progress_data=progress_data)

@app.route('/transactions')
def transactions():
    """Basic transactions page (placeholder for Tasks 3-7)"""
    if 'user_id' not in session:
        return redirect('/login')
    
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Transactions</title>
        <style>
            body { font-family: Arial; margin: 20px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            h1 { color: #333; text-align: center; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>💳 Transaction Management</h1>
            <p style="text-align: center; color: #666;">Tasks 3-7: Implemented by Samantha</p>
            <p style="text-align: center; margin: 30px;">Transaction features would be integrated here.</p>
            <p style="text-align: center;">
                <a href="/dashboard" style="color: #667eea;">← Back to Dashboard</a>
            </p>
        </div>
    </body>
    </html>
    ''')

@app.route('/register')
def register():
    """Registration page (placeholder)"""
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Register</title>
        <style>
            body { font-family: Arial; margin: 50px; text-align: center; }
        </style>
    </head>
    <body>
        <h1>Registration</h1>
        <p>Task 1: User Authentication - Implemented by Gerves</p>
        <p>Registration feature would be here.</p>
        <p><a href="/">Back to Home</a></p>
    </body>
    </html>
    ''')

@app.route('/demo')
def demo():
    """Quick demo without login"""
    # Auto-login as demo user for quick testing
    session['user_id'] = 1
    session['username'] = 'demo'
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    return redirect('/')

@app.route('/add_sample_data')
def add_sample_data():
    """Add sample data for demonstration"""
    conn = get_db_connection()
    c = conn.cursor()
    
    current_month = datetime.now().strftime('%Y-%m')
    user_id = session.get('user_id', 1)  # Use logged in user or demo user
    
    # Clear existing data for this month
    c.execute('DELETE FROM budgets WHERE user_id = ? AND month = ?', (user_id, current_month))
    c.execute('''
        DELETE FROM transactions 
        WHERE user_id = ? AND strftime("%Y-%m", date) = ?
    ''', (user_id, current_month))
    
    # Add sample budgets
    sample_budgets = [
        ('Food', 600.00),
        ('Transportation', 250.00),
        ('Entertainment', 200.00),
        ('Shopping', 300.00),
        ('Utilities', 350.00),
        ('Healthcare', 150.00)
    ]
    
    for category, amount in sample_budgets:
        c.execute('''
            INSERT INTO budgets (user_id, category, amount, month)
            VALUES (?, ?, ?, ?)
        ''', (user_id, category, amount, current_month))
    
    # Add sample transactions with varying spending levels
    sample_transactions = [
        # Food - at 70% of budget (420/600)
        ('Food', 125.50, '2025-10-01', 'Grocery shopping'),
        ('Food', 45.00, '2025-10-05', 'Restaurant'),
        ('Food', 89.99, '2025-10-10', 'Weekly groceries'),
        ('Food', 32.50, '2025-10-12', 'Coffee shop'),
        ('Food', 127.00, '2025-10-15', 'Grocery shopping'),
        
        # Transportation - at 40% of budget (100/250)
        ('Transportation', 50.00, '2025-10-02', 'Gas'),
        ('Transportation', 25.00, '2025-10-08', 'Uber'),
        ('Transportation', 25.00, '2025-10-14', 'Bus pass'),
        
        # Entertainment - at 90% of budget (180/200)
        ('Entertainment', 65.00, '2025-10-03', 'Movie tickets'),
        ('Entertainment', 45.00, '2025-10-09', 'Concert'),
        ('Entertainment', 70.00, '2025-10-13', 'Theme park'),
        
        # Shopping - over budget! (360/300)
        ('Shopping', 150.00, '2025-10-04', 'Clothing'),
        ('Shopping', 89.99, '2025-10-11', 'Electronics'),
        ('Shopping', 120.00, '2025-10-16', 'Home decor'),
        
        # Utilities - at 30% of budget (105/350)
        ('Utilities', 105.00, '2025-10-05', 'Electric bill'),
        
        # Healthcare - at 0% (no expenses yet)
    ]
    
    for category, amount, date, description in sample_transactions:
        c.execute('''
            INSERT INTO transactions (user_id, category, amount, date, type, description)
            VALUES (?, ?, ?, ?, 'expense', ?)
        ''', (user_id, category, amount, date, description))
    
    # Add some income transactions
    c.execute('''
        INSERT INTO transactions (user_id, category, amount, date, type, description)
        VALUES (?, 'Salary', 3000.00, '2025-10-01', 'income', 'Monthly salary')
    ''', (user_id,))
    
    conn.commit()
    conn.close()
    
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Sample Data Added</title>
        <style>
            body { 
                font-family: Arial; 
                display: flex; 
                justify-content: center; 
                align-items: center; 
                min-height: 100vh;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            }
            .success { 
                background: white; 
                padding: 40px; 
                border-radius: 10px; 
                text-align: center;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            }
            h1 { color: #4CAF50; }
            .btn { 
                display: inline-block; 
                margin: 10px; 
                padding: 10px 20px; 
                background: #667eea; 
                color: white; 
                text-decoration: none; 
                border-radius: 5px; 
            }
            .btn:hover { background: #5a67d8; }
        </style>
    </head>
    <body>
        <div class="success">
            <h1>✅ Sample Data Added Successfully!</h1>
            <p>6 budget categories and 15+ transactions have been added.</p>
            <p><strong>Note:</strong> Shopping category is intentionally over budget to demonstrate the red alert!</p>
            <div>
                <a href="/budget" class="btn">View Budgets</a>
                <a href="/budget_progress" class="btn">View Progress Bars</a>
                <a href="/dashboard" class="btn">Go to Dashboard</a>
            </div>
        </div>
    </body>
    </html>
    ''')

# Run the application
if __name__ == '__main__':
    print("\n" + "="*50)
    print("💰 PERSONAL FINANCE TRACKER - MY PALDEA")
    print("="*50)
    print("Team Project - IST 303 Fall 2025")
    print("Featured: Tasks 8-9 by Qiao Huang")
    print("="*50 + "\n")
    
    # Initialize database
    init_db()
    
    print("\n📌 INSTRUCTIONS:")
    print("1. Open your browser")
    print("2. Go to: http://127.0.0.1:5000")
    print("3. Login with: demo / demo123")
    print("4. Click 'Load Sample Data' for demo")
    print("\n✨ Starting server...\n")
    
    app.run(debug=True, port=5000)
